Tetris Mix Multiplayer - Java Sockets
====================================

Estructura:
  src/tetris/*.java

Compilar desde la carpeta TetrisMixMultiplayer:
  javac -d out src/tetris/*.java

Ejecutar servidor:
  java -cp out tetris.Servidor50

Ejecutar cada cliente/jugador:
  java -cp out tetris.Cliente50

Notas:
- No usa WebSocket, Socket.IO ni librerías externas.
- Usa sockets TCP de Java en el puerto 4444.
- El servidor es la autoridad del juego: caída, colisiones, líneas y puntajes.
- Los clientes solo dibujan el tablero y envían teclas.
- Teclas: izquierda, derecha, abajo, A rotación antihoraria, S rotación horaria.

Prueba local:
1) Ejecuta el servidor y acepta valores por defecto: 2 jugadores, 20 filas, 10 columnas.
2) Ejecuta dos veces tetris.Cliente50.
3) En ambos clientes usa IP 127.0.0.1.
4) La partida inicia automáticamente cuando los jugadores configurados envían JOIN.
   También puedes escribir start en la consola del servidor.
