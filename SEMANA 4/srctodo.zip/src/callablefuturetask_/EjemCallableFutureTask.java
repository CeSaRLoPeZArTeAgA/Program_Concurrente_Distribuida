/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package callablefuturetask_;

import java.util.concurrent.*;

public class EjemCallableFutureTask {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);

        // --- 1. Callable ---
        Callable<Integer> sumaCallable = new Callable<Integer>() {
            public Integer call() {
                int suma = 0;
                for (int i = 1; i <= 5; i++) {
                    suma += i; // suma de 1 a 5
                }
                return suma;
            }
        };

        // --- 2. Future ---
        Future<Integer> resultadoFuture = executor.submit(sumaCallable);
        System.out.println("Resultado obtenido con Future (suma): " + resultadoFuture.get());

        // --- 3. FutureTask ---
        FutureTask<Integer> factorialTask = new FutureTask<>(new Callable<Integer>() {
            public Integer call() {
                int factorial = 1;
                for (int i = 1; i <= 5; i++) {
                    factorial *= i; // factorial de 5
                }
                return factorial;
            }
        });

        Thread hilo = new Thread(factorialTask);
        hilo.start();
        System.out.println("Resultado obtenido con FutureTask (factorial): " + factorialTask.get());

        executor.shutdown();
    }
}
