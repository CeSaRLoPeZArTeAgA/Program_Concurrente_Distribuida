/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadpool_;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class EjmThreadPools {
    public static void main(String[] args) throws InterruptedException {
        // Primer ThreadPool: más hilos, tareas rápidas
        ExecutorService pool1 = Executors.newFixedThreadPool(4);

        // Variable compartida para acumular resultados
        final int[] suma = {0};

        // Lanzar varias tareas de cálculo sencillo
        for (int i = 1; i <= 6; i++) {
            final int num = i;
            pool1.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println("Pool1 procesando " + num +
                                       " en " + Thread.currentThread().getName());
                    try {
                        Thread.sleep(500); // Simular trabajo ligero
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    synchronized (suma) {
                        suma[0] += num * 2; // Acumular resultado
                    }
                }
            });
        }

        // Esperar a que terminen todas las tareas del primer pool
        pool1.shutdown();
        pool1.awaitTermination(10, TimeUnit.SECONDS);

        System.out.println("Resultado combinado del Pool1: " + suma[0]);

        // Segundo ThreadPool: menos hilos, tareas más pesadas
        ExecutorService pool2 = Executors.newFixedThreadPool(2);

        // Usar el resultado del primer pool como entrada
        for (int i = 1; i <= 3; i++) {
            final int tareaId = i;
            final int entrada = suma[0];
            pool2.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println("Pool2 procesando tarea " + tareaId +
                                       " con entrada " + entrada +
                                       " en " + Thread.currentThread().getName());
                    // Trabajo aritmético costoso
                    long resultado = 0;
                    for (int j = 1; j <= 5_000_000; j++) {
                        resultado += (entrada * j) % 97;
                    }
                    System.out.println("Tarea " + tareaId +
                                       " completada con resultado " + resultado);
                }
            });
        }

        pool2.shutdown();
    }
}