package ejemvolatile_;

class HiloTrabajador extends Thread {
    private volatile boolean ejecutar;
    private int id;
    private int contador = 0;
    
    public HiloTrabajador(int id_) {
        ejecutar = true;
        id = id_;
    }
    
    @Override
    public void run() {
        System.out.println("Hilo trabajador iniciado: " + id );
        int contador = 0;
        
        while (ejecutar) {
            contador++;
            //if (contador % 1000000000 == 0) {
            //    System.out.println("Hilo " + id + " lleva " + contador + " iteraciones");
            //}
        }
       
        System.out.println("Hilo trabajador " + id + " terminado. Contador: " + contador);
    }
    
    public void detener() {
        System.out.println("Deteniendo hilo trabajador " + id + " ...");
        this.ejecutar = false;
    }
}
public class EjemVolatile {
    
    public static void main(String[] args) throws InterruptedException {
        int H = 3;
        HiloTrabajador[] trabajadores = new HiloTrabajador[H]; 
             
        // Crear el hilo trabajadores
        // Iniciar el hilos
        for (int i = 0; i < H; i++) {
            trabajadores[i] = new HiloTrabajador(i + 1);
            trabajadores[i].start();
        }       
                
        // Dormimos 3 segundos
        Thread.sleep(3000);
        
        // Detener hilos mediante el metodo que cambia volatile
        for (int i = 0; i < H; i++) {
            trabajadores[i].detener();
        }
        
        // Esperamos a que los hilos terminen
        for (int i = 0; i < H; i++) {
            trabajadores[i].join();
        }        
                
        System.out.println("Programa finalizado correctamente");
    }
}