/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package volatilesynchroized_;
class Contador {
    // Volatile asegura visibilidad entre hilos
    private volatile int valor = 0;

    // synchronized asegura atomicidad en la operación
    public synchronized void incrementar() {
        valor++; // operación segura
    }

    public synchronized int getValor() {
        return valor;
    }
}

public class EjemVolatileYSynchronized {
    public static void main(String[] args) throws InterruptedException {
        final Contador contador = new Contador();

        // Crear varios hilos usando clases anónimas (sin "->")
        Thread hilo1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 1000; i++) {
                    contador.incrementar();
                }
            }
        });

        Thread hilo2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 1000; i++) {
                    contador.incrementar();
                }
            }
        });

        Thread hilo3 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 1000; i++) {
                    contador.incrementar();
                }
            }
        });

        // Iniciar los hilos
        hilo1.start();
        hilo2.start();
        hilo3.start();

        // Esperar a que terminen
        hilo1.join();
        hilo2.join();
        hilo3.join();

        System.out.println("Valor esperado: 3000");
        System.out.println("Valor real: " + contador.getValor());
    }
}
