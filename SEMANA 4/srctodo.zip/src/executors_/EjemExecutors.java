
package executors_;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.*;

public class EjemExecutors {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);

        // --- 1. Callable ---
        Callable<Integer> sumaCallable = new Callable<Integer>() {
            public Integer call() {
                int suma = 0;
                for (int i = 1; i <= 10; i++) {
                    suma += i; // suma de 1 a 10
                }
                return suma;
            }
        };

        // --- 2. Future ---
        Future<Integer> resultadoFuture = executor.submit(sumaCallable);
        System.out.println("Resultado obtenido con Future (suma de 1 a 10): " + resultadoFuture.get());

        // --- 3. FutureTask ---
        FutureTask<Integer> factorialTask = new FutureTask<>(new Callable<Integer>() {
            public Integer call() {
                int factorial = 1;
                for (int i = 1; i <= 5; i++) {
                    factorial *= i; // factorial de 5
                }
                return factorial;
            }
        });

        Thread hilo = new Thread(factorialTask);
        hilo.start();
        System.out.println("Resultado obtenido con FutureTask (factorial de 5): " + factorialTask.get());

        executor.shutdown();
    }
}
