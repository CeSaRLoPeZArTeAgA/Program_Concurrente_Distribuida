/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scheduledexecutorservice_;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class EjemScheduledExecutor {
    public static void main(String[] args) {
        // Crear un ScheduledExecutor con 3 hilos
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);

        // Tarea 1: ejecutar una vez después de 2 segundos
        scheduler.schedule(new Runnable() {
            @Override
            public void run() {
                System.out.println("Tarea 1 ejecutada en " + Thread.currentThread().getName());
            }
        }, 2, TimeUnit.SECONDS);

        // Tarea 2: ejecutar cada 3 segundos, empezando después de 1 segundo
        scheduler.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                System.out.println("Tarea 2 ejecutada en " + Thread.currentThread().getName());
            }
        }, 1, 3, TimeUnit.SECONDS);

        // Tarea 3: ejecutar cada 4 segundos, pero contando desde que termina la tarea
        scheduler.scheduleWithFixedDelay(new Runnable() {
            @Override
            public void run() {
                System.out.println("Tarea 3 ejecutada en " + Thread.currentThread().getName());
                try {
                    Thread.sleep(2000); // Simular trabajo costoso
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }, 1, 4, TimeUnit.SECONDS);

        // El scheduler seguirá ejecutando tareas en segundo plano
        // Para detenerlo después de cierto tiempo:
        scheduler.schedule(new Runnable() {
            @Override
            public void run() {
                System.out.println("Apagando scheduler...");
                scheduler.shutdown();
            }
        }, 20, TimeUnit.SECONDS);
    }
}
