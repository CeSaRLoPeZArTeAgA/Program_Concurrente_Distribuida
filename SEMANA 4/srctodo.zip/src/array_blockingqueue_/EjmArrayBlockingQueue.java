/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array_blockingqueue_;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ArrayBlockingQueue;

public class EjmArrayBlockingQueue {
    public static void main(String[] args) throws InterruptedException {
        // Cola declarada como interfaz BlockingQueue (capacidad 2)
        BlockingQueue<Integer> colaOperaciones = new ArrayBlockingQueue<>(2);

        // Cola declarada directamente como ArrayBlockingQueue (capacidad 3)
        ArrayBlockingQueue<Integer> colaNumeros = new ArrayBlockingQueue<>(3);

        // --- Productor de operaciones aritméticas ---
        for (int i = 1; i <= 3; i++) {
            System.out.println("Productor de operaciones: poniendo " + i);
            colaOperaciones.put(i); // la tercera se bloqueará hasta que alguien consuma
        }

        // --- Consumidor de operaciones ---
        Thread consumidorOperaciones = new Thread(new Runnable() {
            public void run() {
                try {
                    while (true) {
                        int valor = colaOperaciones.take();
                        System.out.println("Consumidor de operaciones: sacó " + valor);
                        int resultado = 0;
                        // bucle con operación aritmética: suma de cuadrados
                        for (int j = 1; j <= valor; j++) {
                            resultado += j * j;
                        }
                        System.out.println("Suma de cuadrados hasta " + valor + " = " + resultado);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        consumidorOperaciones.start();

        // --- Productor de números ---
        for (int i = 1; i <= 4; i++) {
            System.out.println("Productor de números: poniendo " + i);
            colaNumeros.put(i); // el cuarto se bloqueará hasta que alguien consuma
        }

        // --- Consumidor de números ---
        Thread consumidorNumeros = new Thread(new Runnable() {
            public void run() {
                try {
                    while (true) {
                        int num = colaNumeros.take();
                        System.out.println("Consumidor de números: sacó " + num);
                        int factorial = 1;
                        // bucle con operación aritmética: calcular factorial
                        for (int j = 1; j <= num; j++) {
                            factorial *= j;
                        }
                        System.out.println("Factorial de " + num + " = " + factorial);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        consumidorNumeros.start();
    }
}
