/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NotifyNotifyAll_;

class Recurso {
    private boolean disponible = false;

    public synchronized void producir() {
        disponible = true;
        System.out.println("Productor: recurso disponible");
        // notify();    // Solo despierta a un hilo
        notifyAll();    // Despierta a todos los hilos
    }

    public synchronized void consumir(String nombre) {
        while (!disponible) {
            try {
                System.out.println(nombre + " esperando recurso...");
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println(nombre + " consumió el recurso");
        disponible = false;
    }
}

public class EjmNotifyNotifyAll {
    public static void main(String[] args) {
        Recurso recurso = new Recurso();

        // Varios consumidores
        for (int i = 1; i <= 3; i++) {
            final String nombre = "Consumidor-" + i;
            new Thread(() -> recurso.consumir(nombre)).start();
        }

        // Productor
        new Thread(() -> {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            recurso.producir();
        }).start();
    }
}
