/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atomicintege_;

import java.util.concurrent.atomic.AtomicInteger;

class ContadorAtomic {
    private AtomicInteger valor = new AtomicInteger(0);

    public void incrementar() {
        valor.incrementAndGet(); // operación atómica
    }

    public int getValor() {
        return valor.get();
    }
}

public class EjemAtomicInteger {
    public static void main(String[] args) throws InterruptedException {
        final ContadorAtomic contador = new ContadorAtomic();

        // Crear dos hilos usando clases anónimas (sin "->")
        Thread hilo1 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 1000; i++) {
                    contador.incrementar();
                }
            }
        });

        Thread hilo2 = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 1000; i++) {
                    contador.incrementar();
                }
            }
        });

        // Iniciar los hilos
        hilo1.start();
        hilo2.start();

        // Esperar a que terminen
        hilo1.join();
        hilo2.join();

        System.out.println("Valor esperado: 2000");
        System.out.println("Valor real: " + contador.getValor());
    }
}
