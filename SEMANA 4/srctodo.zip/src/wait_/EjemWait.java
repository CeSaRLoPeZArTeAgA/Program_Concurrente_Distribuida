/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wait_;

class RecursoCompartido {
    private boolean disponible = false;

    public synchronized void producir() {
        System.out.println("Productor: creando recurso...");
        disponible = true;
        notify(); // Avisar a un consumidor que ya hay recurso
    }

    public synchronized void consumir() {
        while (!disponible) {
            try {
                System.out.println("Consumidor: esperando recurso...");
                wait(); // Esperar hasta que el productor avise
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        System.out.println("Consumidor: recurso consumido!");
        disponible = false;
    }
}

public class EjemWait {
    public static void main(String[] args) {
        RecursoCompartido recurso = new RecursoCompartido();

        // Hilo consumidor
        Thread consumidor = new Thread(new Runnable() {
            @Override
            public void run() {
                recurso.consumir();
            }
        });

        // Hilo productor
        Thread productor = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000); // Simular tiempo de producción
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                recurso.producir();
            }
        });

        consumidor.start();
        productor.start();
    }
}
